package com.labtvmonolitico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabtvMonoliticoApplication {

	public static void main(String[] args) {
		SpringApplication.run(LabtvMonoliticoApplication.class, args);
	}

}
