package com.labtvmonolitico.dao;

import org.springframework.data.repository.CrudRepository;

import com.labtvmonolitico.model.*;


public interface EvidenzaDao extends CrudRepository<Evidenza, Integer> {

}
