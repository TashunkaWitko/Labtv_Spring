package com.labtvmonolitico.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.labtvmonolitico.model.Director;


public interface DirectorDao extends CrudRepository<Director, Integer> {

	
	@Query(value = "SELECT * FROM directors WHERE id= :id ", nativeQuery = true)
	Director getDirectorByID(@Param("id") int id);
}
