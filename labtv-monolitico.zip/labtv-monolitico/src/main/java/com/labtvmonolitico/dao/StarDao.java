package com.labtvmonolitico.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.labtvmonolitico.model.*;;

public interface StarDao extends CrudRepository<Star, Integer> {

	@Query(value = "SELECT * FROM stars WHERE id= :id ", nativeQuery = true)
	Star getStarByID(@Param("id") int id);
}
