package com.labtvmonolitico.dao;


import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.labtvmonolitico.model.*;

public interface TrailerDao extends CrudRepository<Trailer, Integer>{
	
	@Query(value="SELECT * FROM trailers WHERE id_film= :id",nativeQuery = true)
	Trailer getTrailerByIdFilm(@Param("id") String id);

}
