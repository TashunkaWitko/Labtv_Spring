package com.labtvmonolitico.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.labtvmonolitico.model.*;

public interface SimilarDao extends CrudRepository<Similar,Integer> {

	@Query(value = "SELECT * FROM similars WHERE id= :id ", nativeQuery = true)
	Similar getSimilarByID(@Param("id") int id);
}
