package com.labtvmonolitico.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.labtvmonolitico.model.*;

import com.labtvmonolitico.service.*;

@Controller
@RequestMapping("/")

public class EvidenzaController {
	
	@Autowired
	EvidenzaService evidenzaService;

	@GetMapping("evidenze")
	public String getPage(Model model) 
	{
		List<Evidenza> evidenze = evidenzaService.getEvidenza();
		model.addAttribute("evidenze",evidenze);
		return "evidenze.html";
	}
	
	
}
