package com.labtvmonolitico.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.labtvmonolitico.model.*;

import com.labtvmonolitico.service.*;

@Controller
@RequestMapping("/")

public class StarController {
	
	@Autowired
	StarService starService;

	@GetMapping("star")
	public String getPage(Model model) 
	{
		List<Star> stars = starService.getStar();
		model.addAttribute("stars",stars);
		model.addAttribute("star", new Star());
		return "star.html";
	}
	
	@PostMapping("insertStar")
	public String insertDirecotr(@ModelAttribute("star") Star star, BindingResult result,Model model) 
	{
		starService.addStar(star);
		List<Star> stars = starService.getStar();
		model.addAttribute("stars",stars);
		model.addAttribute("star", new Star());
		return "star.html";
	}
	
	@GetMapping("deleteStar/{id}")
	public String deleteStar(@PathVariable("id") int id, Model model) 
	{
		starService.deleteStarById(id);
		return "redirect:/star";
	}
	
	
}
