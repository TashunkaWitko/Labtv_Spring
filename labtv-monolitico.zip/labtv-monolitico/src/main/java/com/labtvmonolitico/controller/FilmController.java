package com.labtvmonolitico.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import com.labtvmonolitico.model.*;

import com.labtvmonolitico.service.*;

@Controller
@RequestMapping("/")

public class FilmController {
	
	@Autowired
	FilmService filmService;

	@GetMapping("film")
	public String getFilms(Model model) 
	{
		List<Film> films = filmService.getFilm();
		model.addAttribute("films", films);
		return "film.html";
	}
	
	@GetMapping("/{id}")
	public String getFilmDetail(@PathVariable("id") String id,Model model)
	{
		 Film details = filmService.getFilmById(id);
		 model.addAttribute("details",details);
		 return "film.html";
	}
		
	@GetMapping("search")
	 public String home(Film film, Model model, String title) {
		  if(title!=null) {
		   List<Film> films = filmService.getFilmByTitle(title);
		   model.addAttribute("films", films);
		   System.out.println(films);
		  }
		  return "film.html";
		 }
	
	@GetMapping("delete/{id}")
	public String deleteFilm(@PathVariable("id") String id, Model model)
	{
		 Film to_delete = filmService.getFilmById(id);
		 filmService.deleteFilm(to_delete);
		 List<Film> films = filmService.getFilm();
		 model.addAttribute("films", films);
		 return "film.html";
	}
}
