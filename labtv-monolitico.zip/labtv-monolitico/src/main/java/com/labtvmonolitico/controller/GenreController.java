package com.labtvmonolitico.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.labtvmonolitico.model.*;

import com.labtvmonolitico.service.*;

@Controller
@RequestMapping("/")

public class GenreController {
	
	@Autowired
	GenreService genreService;

	@GetMapping("genre")
	public String getPage(Model model) 
	{
		List<Genre> genres = genreService.getGenre();
		model.addAttribute("genres", genres);
		model.addAttribute("genre", new Genre());
		return "genre.html";
	}
	
	@PostMapping("insertGenre")
	public String insertGenre(@ModelAttribute("genre") Genre genre, BindingResult result,Model model) 
	{
		genreService.addGenre(genre);
		List<Genre> genres = genreService.getGenre();
		model.addAttribute("genres",genres);
		model.addAttribute("genre", new Genre());
		return "genre.html";
	}
	
	@GetMapping("deleteGenre/{id}")
	public String deleteGenre(@PathVariable("id") int id, Model model) 
	{
		genreService.deleteGenreById(id);
		return "redirect:/genre";
	}
	
	
}