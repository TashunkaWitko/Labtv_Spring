package com.labtvmonolitico.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.labtvmonolitico.model.*;

import com.labtvmonolitico.service.*;

@Controller
@RequestMapping("/")

public class DirectorController {
	
	@Autowired
	DirectorService directorService;

	@GetMapping("director")
	public String getPage(Model model) 
	{
		List<Director> directors = directorService.getDirector();
		model.addAttribute("directors",directors);
		model.addAttribute("director", new Director());
		return "director.html";
	}
	
	@PostMapping("insertDirector")
	public String insertDirecotr(@ModelAttribute("director") Director director, BindingResult result,Model model) 
	{
		directorService.addDirector(director);
		List<Director> directors = directorService.getDirector();
		model.addAttribute("directors",directors);
		model.addAttribute("director", new Director());
		return "director.html";
	}
	
	@GetMapping("deleteDirector/{id}")
	public String deleteDirector(@PathVariable("id") int id, Model model) 
	{
		directorService.deleteDirectorById(id);
		return "redirect:/director";
	}
	
}
