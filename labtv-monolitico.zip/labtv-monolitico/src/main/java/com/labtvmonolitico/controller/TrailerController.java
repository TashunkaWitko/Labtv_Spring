package com.labtvmonolitico.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.labtvmonolitico.model.*;

import com.labtvmonolitico.service.*;

@Controller
@RequestMapping("/")

public class TrailerController {
	
	@Autowired
	TrailerService trailerService;
		
	@GetMapping("/trailer/{id_trailer}")
	public String getFilmTrailer(@PathVariable("id_trailer") String id, Model model)
	{
	 Trailer trailers= trailerService.getTrailerByIdFilm(id);
	 model.addAttribute("trailers",trailers);
	 return "trailer.html";
	}
}
