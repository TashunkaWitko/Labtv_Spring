package com.labtvmonolitico.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.labtvmonolitico.model.*;

import com.labtvmonolitico.service.*;

@Controller
@RequestMapping("/")

public class SimilarController {
	
	@Autowired
	SimilarService similarService;

	@GetMapping("similar")
	public String getPage(Model model) 
	{
		List<Similar> similars = similarService.getSimilar();
		model.addAttribute("similars", similars);
		model.addAttribute("similar", new Similar());
		return "similar.html";
	}
	
	@PostMapping("insertSimilar")
	public String insertSimilar(@ModelAttribute("similar") Similar similar, BindingResult result,Model model) 
	{
		similarService.addSimilar(similar);
		List<Similar> similars = similarService.getSimilar();
		model.addAttribute("similars", similars);
		model.addAttribute("similar", new Similar());
		return "similar.html";
	}
	
	@GetMapping("deleteSimilar/{id}")
	public String deleteSimilar(@PathVariable("id") int id, Model model) 
	{
		similarService.deleteSimilarById(id);
		return "redirect:/similar";
	}
	
}