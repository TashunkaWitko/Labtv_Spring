package com.labtvmonolitico.model;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "evidenza")
public class Evidenza {

	@Id
	private String id;
	
	@Column(name = "rank")
	private double rank;
	
	@Column(name = "rankUpDown")
	private double rankUpDown;
	
	@Column(name = "title")
	private String title;
	
	@Column(name = "fullTitle")
	private String full_title;
	
	@Column(name = "year")
	private double year;
	
	@Column(name = "image")
	private String image;
	
	@Column(name = "crew")
	private String crew;
	
	@Column(name = "imDbRating")
	private String imDbRating;
	
	@Column(name = "imDbRatingCount")
	private String imDbRatingCount;
	
	
	public String getId() {
		return this.id;
	}
	
	public void setId(String id){
		this.id=id;
	}
	
	public double getRank() {
		return this.rank;
	}
	
	public void getRank(double rank) {
		this.rank=rank;
	}
	
	public double getRankUpDown() {
		return this.rankUpDown;
	}
	
	public void getRankUpDown(double rankUpDown) {
		this.rankUpDown=rankUpDown;
	}
	public String getTitle() {
		return this.title;
	}
	
	public void setTitle(String title){
		this.title=title;
	}
	
	public String getFullTitle() {
		return this.full_title;
	}
	
	public void setFullTitle(String full_title){
		this.full_title=full_title;
	}
	
	public double getYear() {
		return this.year;
	}
	
	public void setYear(double year) {
		this.year=year;
	}
	
	public String getImage() {
		return this.image;
	}
	
	public void setImage(String image){
		this.image=image;
	}
	
	public String getCrew() {
		return this.crew;
	}
	
	public void setCrew(String crew){
		this.crew=crew;
	}
	
	public String getImDbRating() {
		return this.imDbRating;
	}
	
	public void setImDbRating(String imDbRating){
		this.imDbRating=imDbRating;
	}
	
	public String getImDbRatingCount(){
		return this.imDbRatingCount;
	}
	
	public void setImDbRatingCount(String imDbRatingCount){
		this.imDbRatingCount=imDbRatingCount;
	}
}
