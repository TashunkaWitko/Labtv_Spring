package com.labtvmonolitico.model;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="genres")
public class Genre {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private int id;
	
	@OneToMany(
			mappedBy = "genres",
			orphanRemoval = true,
			cascade = CascadeType.REFRESH,
			fetch = FetchType.EAGER
			)
	
	private List<Film> films = new ArrayList<Film>();
	
	@Column(name="Nome_Genre")
	private String nomeGenre;
	
	
	public int getIdGenre() {
		return this.id;
	}
	
	public void setIdGenre(int id_genre) {
		this.id=id_genre;
	}
	
	public String getNomeGenre() {
		return this.nomeGenre;
	}
	
	public void setNomeGenre(String nomeGenre) {
		this.nomeGenre=nomeGenre;
	}
	
}
