package com.labtvmonolitico.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="stars")
public class Star {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@OneToMany(
			mappedBy = "stars",
			cascade = CascadeType.REFRESH,
			fetch = FetchType.EAGER,
			orphanRemoval = true)
	private List<Film> films = new ArrayList<Film>();
	
	@Column(name="Nome_Star")
	private String nomeStar;
	
	@Column(name="Cognome_Star")
	private String cognomeStar;
	
	@Column(name="Dettaglio_Star")
	private String dettaglioStar;
	
	
	public int getIdStar() {
		return this.id;
	}
	
	public void setIdStar(int id_star) {
		this.id=id_star;
	}
	
	public String getNomeStar() {
		return this.nomeStar;
	}
	
	public void setNomeStar(String nomeStar) {
		this.nomeStar=nomeStar;
	}
	
	public String getCognomeStar() {
		return this.cognomeStar;
	}
	
	public void setCognomeStar(String cognomeStar) {
		this.cognomeStar=cognomeStar;
	}
	
	public String getDettaglioStar() {
		return this.dettaglioStar;
	}
	
	public void setDettaglioStar(String dettaglioStar) {
		this.dettaglioStar=dettaglioStar;
	}
	
}
