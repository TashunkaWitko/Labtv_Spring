package com.labtvmonolitico.model;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="directors")
public class Director {
	
	@Id
	private int id;
	
	@OneToMany(
			mappedBy = "directors",
			orphanRemoval = true,
			fetch = FetchType.EAGER, 
			cascade = CascadeType.REFRESH )
	private List<Film> films  = new ArrayList<Film>();
	
	@Column(name="Nome_Director")
	private String nomeDirector;
	
	@Column(name="Cognome_Director")
	private String cognomeDirector;

	
	public int getIdDirector() {
		return this.id;
	}
	
	public void setIdDirector(int id_director) {
		this.id=id_director;
	}
	
	public String getNomeDirector() {
		return this.nomeDirector;
	}
	
	public void setNomeDirector(String nomeDirector) {
		this.nomeDirector=nomeDirector;
	}
	
	public String getCognomeDirector() {
		return this.cognomeDirector;
	}
	
	public void setCognomeDirector(String cognomeDirector) {
		this.cognomeDirector=cognomeDirector;
	}
}
