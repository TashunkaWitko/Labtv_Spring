package com.labtvmonolitico.service;
import java.util.List;

import com.labtvmonolitico.model.*;

public interface GenreService {

	List<Genre> getGenre();
	void addGenre(Genre genre);
	void deleteGenreById(int id);
}
