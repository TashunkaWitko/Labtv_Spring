package com.labtvmonolitico.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.labtvmonolitico.dao.*;
import com.labtvmonolitico.model.*;

@Service
public class FilmServiceImpl implements FilmService {

	@Autowired
	private FilmDao filmDao;
	

	@Override
	public List<Film> getFilm(){
		List<Film> films = (List<Film>) filmDao.findAll();
		return films;
	}

	@Override
	public Film getFilmById(String id) {
		Film filmbyid = filmDao.getFilmByID(id);
		return filmbyid;
	}

	@Override
	public List<Film> getFilmByTitle(String title) {
		List<Film> filmbytitle = (List<Film>) filmDao.getFilmByTitle(title);
		return filmbytitle;
	}
	
	@Override
	public void insertFilm(Film film) {
		filmDao.save(film);
	}
	
	@Override
	public void deleteFilm(Film film) {
		filmDao.delete(film);
	}
}
