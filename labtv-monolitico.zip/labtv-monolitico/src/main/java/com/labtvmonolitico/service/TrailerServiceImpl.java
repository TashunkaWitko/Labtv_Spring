package com.labtvmonolitico.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.labtvmonolitico.dao.*;
import com.labtvmonolitico.model.*;

@Service
public class TrailerServiceImpl implements TrailerService{
	
	@Autowired
	private TrailerDao trailerDao;

	@Override
	public List<Trailer> getTrailer() {
		List<Trailer> trailers = (List<Trailer>) trailerDao.findAll();
		return trailers;
	}

	@Override
	public Trailer getTrailerByIdFilm(String id_film) {
		Trailer trailersbyidfilm = trailerDao.getTrailerByIdFilm(id_film);
		return  trailersbyidfilm;
	}

}
