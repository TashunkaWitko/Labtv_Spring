package com.labtvmonolitico.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.labtvmonolitico.dao.*;
import com.labtvmonolitico.model.*;

@Service
public class StarServiceImpl implements StarService{
	
	@Autowired
	private StarDao starDao;

	@Override
	public List<Star> getStar() {
		List<Star> stars = (List<Star>) starDao.findAll();
		return stars;
	}

	@Override
	public void addStar(Star star) {
		starDao.save(star);
		
	}

	@Override
	public void deleteStarById(int id) {
		Star todelete_Star = starDao.getStarByID(id);
		starDao.delete(todelete_Star);
		
	}
	


}
