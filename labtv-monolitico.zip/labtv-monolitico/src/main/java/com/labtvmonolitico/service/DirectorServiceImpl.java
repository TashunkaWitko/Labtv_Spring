package com.labtvmonolitico.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.labtvmonolitico.dao.*;
import com.labtvmonolitico.model.*;
@Service
public class DirectorServiceImpl implements DirectorService {
	
	@Autowired
	private DirectorDao directorDao;

	@Override
	public List<Director> getDirector() {
		List<Director> directors = (List<Director>) directorDao.findAll();
		return directors;
	}

	@Override
	public void addDirector(Director director) {
		directorDao.save(director);
	}

	@Override
	public void deleteDirectorById(int id) {
		Director to_deleteDirector = directorDao.getDirectorByID(id);
		directorDao.delete(to_deleteDirector);
	}

}
