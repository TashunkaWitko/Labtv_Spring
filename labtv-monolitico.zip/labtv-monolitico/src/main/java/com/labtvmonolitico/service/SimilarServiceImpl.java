package com.labtvmonolitico.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.labtvmonolitico.dao.*;
import com.labtvmonolitico.model.*;
@Service
public class SimilarServiceImpl implements SimilarService {
	
	@Autowired
	private SimilarDao similarDao;

	@Override
	public List<Similar> getSimilar() {
		List<Similar> similars = (List<Similar>) similarDao.findAll();
		return similars;
	}

	@Override
	public void addSimilar(Similar similar) {
		similarDao.save(similar);
	}

	@Override
	public void deleteSimilarById(int id) {
		Similar todelete_similar = similarDao.getSimilarByID(id);
		similarDao.delete(todelete_similar);
		
	}

}
