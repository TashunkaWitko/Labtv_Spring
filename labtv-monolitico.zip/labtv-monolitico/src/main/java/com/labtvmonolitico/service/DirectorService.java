package com.labtvmonolitico.service;
import java.util.List;

import com.labtvmonolitico.model.*;

public interface DirectorService {
	
	List<Director> getDirector();
	void addDirector(Director director);
	void deleteDirectorById(int id);

}
