package com.labtvmonolitico.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.labtvmonolitico.dao.*;
import com.labtvmonolitico.model.*;
@Service
public class GenreServiceImpl implements GenreService {
	
	@Autowired
	
	private GenreDao genreDao;

	@Override
	public List<Genre> getGenre() {
		List<Genre> genres = (List<Genre>) genreDao.findAll();
		return genres;
	}

	@Override
	public void addGenre(Genre genre) {
		genreDao.save(genre);
		
	}

	@Override
	public void deleteGenreById(int id) {
		Genre to_deleteGenre = genreDao.getGenreByID(id);
		genreDao.delete(to_deleteGenre);
		
	}

}
