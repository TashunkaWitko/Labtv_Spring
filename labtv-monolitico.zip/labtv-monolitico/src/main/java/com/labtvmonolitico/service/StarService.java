package com.labtvmonolitico.service;
import java.util.List;

import com.labtvmonolitico.model.*;

public interface StarService {
	
	List<Star> getStar();
	void addStar(Star star);
	void deleteStarById(int id);

}
