package com.labtvmonolitico.service;

import com.labtvmonolitico.dao.*;
import com.labtvmonolitico.model.*;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EvidenzaServiceImpl implements EvidenzaService{
	
	@Autowired
	private EvidenzaDao evidenzaDao;
	
	@Override
	public List<Evidenza> getEvidenza(){
		
		List<Evidenza> evidenza = (List<Evidenza>) evidenzaDao.findAll();
		
		return evidenza;
	}

}
