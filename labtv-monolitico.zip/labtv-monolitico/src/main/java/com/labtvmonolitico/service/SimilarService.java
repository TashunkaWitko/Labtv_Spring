package com.labtvmonolitico.service;
import java.util.List;

import com.labtvmonolitico.model.*;

public interface SimilarService {

	List<Similar> getSimilar();
	void addSimilar(Similar similar);
	void deleteSimilarById(int id);
}
