package com.labtvmonolitico.service;
import java.util.List;

import com.labtvmonolitico.model.*;

public interface FilmService {

	List<Film> getFilm();
	Film getFilmById(String id);
	List<Film> getFilmByTitle(String title);
	void insertFilm(Film film);
	void deleteFilm(Film film);
}
