package com.labtvmonolitico.service;
import java.util.List;

import com.labtvmonolitico.model.*;

public interface EvidenzaService {

	List<Evidenza> getEvidenza();

}
