package com.labtvmonolitico.service;
import java.util.*;
import com.labtvmonolitico.model.*;

public interface TrailerService {
	
	List<Trailer> getTrailer();
	Trailer getTrailerByIdFilm(String id_film);

}
