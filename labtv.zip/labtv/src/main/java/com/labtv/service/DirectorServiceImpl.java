package com.labtv.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.labtv.dao.DirectorDao;
import com.labtv.model.Director;
@Service
public class DirectorServiceImpl implements DirectorService {
	
	@Autowired
	private DirectorDao directorDao;

	@Override
	public List<Director> getDirector() {
		List<Director> directors = (List<Director>) directorDao.findAll();
		return directors;
	}

}
