package com.labtv.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.labtv.dao.StarDao;
import com.labtv.model.Star;

@Service
public class StarServiceImpl implements StarService{
	
	@Autowired
	private StarDao starDao;

	@Override
	public List<Star> getStar() {
		List<Star> stars = (List<Star>) starDao.findAll();
		return stars;
	}
	


}
