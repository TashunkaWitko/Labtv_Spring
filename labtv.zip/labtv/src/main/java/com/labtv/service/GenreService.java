package com.labtv.service;
import java.util.List;

import com.labtv.model.Genre;

public interface GenreService {

	List<Genre> getGenre();
}
