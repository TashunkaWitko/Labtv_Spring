package com.labtv.service;
import java.util.List;

import com.labtv.model.Evidenza;

public interface EvidenzaService {

	List<Evidenza> getEvidenza();

}
