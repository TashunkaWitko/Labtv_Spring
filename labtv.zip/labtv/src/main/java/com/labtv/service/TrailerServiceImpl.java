package com.labtv.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.labtv.dao.TrailerDao;
import com.labtv.model.Trailer;

@Service
public class TrailerServiceImpl implements TrailerService{
	
	@Autowired
	private TrailerDao trailerDao;

	@Override
	public List<Trailer> getTrailer() {
		List<Trailer> trailers = (List<Trailer>) trailerDao.findAll();
		return trailers;
	}

	@Override
	public List<Trailer> getTrailerByIdFilm(String id_film) {
		List<Trailer> trailersbyidfilm = (List<Trailer>) trailerDao.getTrailerByIdFilm(id_film);
		return  trailersbyidfilm;
	}

}
