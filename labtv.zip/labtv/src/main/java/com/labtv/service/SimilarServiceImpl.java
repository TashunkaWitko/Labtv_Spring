package com.labtv.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.labtv.dao.SimilarDao;
import com.labtv.model.Similar;
@Service
public class SimilarServiceImpl implements SimilarService {
	
	@Autowired
	private SimilarDao similarDao;

	@Override
	public List<Similar> getSimilar() {
		List<Similar> similars = (List<Similar>) similarDao.findAll();
		return similars;
	}

}
