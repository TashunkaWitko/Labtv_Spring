package com.labtv.service;
import java.util.*;
import com.labtv.model.*;

public interface TrailerService {
	
	List<Trailer> getTrailer();
	List<Trailer> getTrailerByIdFilm(String id_film);

}
