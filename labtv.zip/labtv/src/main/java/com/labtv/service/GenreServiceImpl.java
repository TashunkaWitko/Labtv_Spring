package com.labtv.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.labtv.dao.GenreDao;
import com.labtv.model.Genre;
@Service
public class GenreServiceImpl implements GenreService {
	
	@Autowired
	
	private GenreDao gerneDao;

	@Override
	public List<Genre> getGenre() {
		List<Genre> genres = (List<Genre>) gerneDao.findAll();
		return genres;
	}

}
