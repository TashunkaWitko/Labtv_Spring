package com.labtv.service;
import java.util.List;

import com.labtv.model.Director;

public interface DirectorService {
	
	List<Director> getDirector();

}
