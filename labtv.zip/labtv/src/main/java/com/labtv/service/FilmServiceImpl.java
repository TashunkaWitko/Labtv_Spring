package com.labtv.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.labtv.dao.FilmDao;
import com.labtv.model.Film;

@Service
public class FilmServiceImpl implements FilmService {

	@Autowired
	
	private FilmDao filmDao;
	

	@Override
	public List<Film> getFilm(){
		
		List<Film> films = (List<Film>) filmDao.findAll();
		return films;
		
	}


	@Override
	public List<Film> getFilmById(String id) {
		List<Film> filmbyid = (List<Film>) filmDao.getFilmByID(id);
		return filmbyid;
	}


	@Override
	public List<Film> getFilmByTitle(String title) {
		List<Film> filmbytitle = (List<Film>) filmDao.getFilmByTitle(title);
		return filmbytitle;
	}
	
	
}
