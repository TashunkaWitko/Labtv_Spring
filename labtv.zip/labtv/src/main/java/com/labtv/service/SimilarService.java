package com.labtv.service;
import java.util.List;

import com.labtv.model.Similar;

public interface SimilarService {

	List<Similar> getSimilar();
}
