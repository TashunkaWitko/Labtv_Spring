package com.labtv.service;
import java.util.List;

import com.labtv.model.Star;

public interface StarService {
	
	List<Star> getStar();

}
