package com.labtv.restcontroller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.labtv.model.Trailer;
import com.labtv.service.TrailerService;

@RestController
@RequestMapping("/api-labtv/api")

 public class TrailerController {
	
	@Autowired
    private	TrailerService trailerService;
	
	@GetMapping("/trailers")
	
	public List<Trailer> geTrailers(){
		return trailerService.getTrailer();
	}
	
	@GetMapping("/trailers/{id_film}")
	
	public List<Trailer> geTrailersByIdFilm(@PathVariable String id_film){
		return trailerService.getTrailerByIdFilm(id_film);
	}
}
