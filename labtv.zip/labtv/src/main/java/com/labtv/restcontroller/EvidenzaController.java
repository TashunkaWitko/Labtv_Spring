package com.labtv.restcontroller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.labtv.model.Evidenza;

import com.labtv.service.EvidenzaService;

@RestController
@RequestMapping("/api-labtv/api")

public class EvidenzaController {
	
	@Autowired
	EvidenzaService evidenzaService;
	
	@GetMapping("/evidenze")
	
	public List<Evidenza> getEvidenza(){
		return	evidenzaService.getEvidenza();
	}
	
}
