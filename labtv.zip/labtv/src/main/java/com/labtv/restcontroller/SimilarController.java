package com.labtv.restcontroller;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.labtv.model.Similar;
import com.labtv.service.SimilarService;

@RestController
@RequestMapping("/api-labtv/api")

public class SimilarController {
	
	@Autowired
	private SimilarService similarService;
	
	@GetMapping("/similars")
	
	public List<Similar> getSimilar(){
		return similarService.getSimilar();
	}
}
