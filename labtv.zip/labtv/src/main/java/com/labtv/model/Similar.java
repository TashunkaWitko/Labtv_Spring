package com.labtv.model;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="similars")
public class Similar {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@OneToMany(
			mappedBy = "similars",
			orphanRemoval = true, 
			fetch = FetchType.EAGER,
			cascade = CascadeType.REFRESH
			)
	
	private List<Film> films = new ArrayList<Film>();
	
	@Column(name="title")
	private String title;
	
	
	@Column(name="image")
	private String image;
	
	
	@Column(name="plot")
	private String plot;
	
	public int getIdSimilar() {
		return this.id;
	}
	
	public void setIdSimilar(int id_similar) {
		this.id=id_similar;
	}
	
	public String getTitleSimilar() {
		return this.title;
	}
	
	public void setTitleSimilar(String title) {
		this.title=title;
	}
	
	public String getImageSimilar() {
		return this.image;
	}
	
	public void setImageSimilar(String image) {
		this.image=image;
	}
	
	public String getPlotSimilar() {
		return this.plot;
	}
	
	public void setPlotSimilar(String plot) {
		this.plot=plot;
	}
}
