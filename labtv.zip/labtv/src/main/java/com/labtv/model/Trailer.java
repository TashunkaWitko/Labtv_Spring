package com.labtv.model;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="trailers")
public class Trailer {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@ManyToOne
	@JoinColumn(name = "id_film",referencedColumnName = "id")
	private Film films;
	
	@Column(name="video_url")
	private String video_url;
	
	
	public int getId() {
		return this.id;
	}
	
	public void setId(int id_trailer) {
		this.id=id_trailer;
	}
	
	public Film getIdFilm() {
		return this.films;
	}
	
	public void setIdFilm(Film id_film) {
		this.films=id_film;
	}
	
	public String getVideoUrl() {
		return this.video_url;
	}
	
	public void setVideoUrl(String video_url) {
		this.video_url=video_url;
	}

}
