package com.labtv.model;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="directors")
public class Director {
	
	@Id
	private int id;
	
	@OneToMany(
			mappedBy = "directors",
			orphanRemoval = true,
			fetch = FetchType.EAGER, 
			cascade = CascadeType.REFRESH )
	private List<Film> films  = new ArrayList<Film>();
	
	@Column(name="Nome_Director")
	private String nome_director;
	
	@Column(name="Cognome_Director")
	private String cognome_director;

	
	public int getIdDirector() {
		return this.id;
	}
	
	public void setIdDirector(int id_director) {
		this.id=id_director;
	}
	
	public String getNomeDirector() {
		return this.nome_director;
	}
	
	public void setNomeDirector(String nome_director) {
		this.nome_director=nome_director;
	}
	
	public String getCognomeDirector() {
		return this.cognome_director;
	}
	
	public void setCognomeDirector(String cognome_director) {
		this.cognome_director=cognome_director;
	}
}
