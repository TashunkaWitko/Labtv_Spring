package com.labtv.model;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="stars")
public class Star {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@OneToMany(
			mappedBy = "stars",
			cascade = CascadeType.REFRESH,
			fetch = FetchType.EAGER,
			orphanRemoval = true)
	private List<Film> films = new ArrayList<>();
	
	@Column(name="Nome_Star")
	private String nome_star;
	
	@Column(name="Cognome_Star")
	private String cognome_star;
	
	
	public int getIdStar() {
		return this.id;
	}
	
	public void setIdStar(int id_star) {
		this.id=id_star;
	}
	
	public String getNomeStar() {
		return this.nome_star;
	}
	
	public void setNomeStar(String nome_star) {
		this.nome_star=nome_star;
	}
	
	public String getCognomeStar() {
		return this.cognome_star;
	}
	
	public void setCognomeStar(String cognome_star) {
		this.cognome_star=cognome_star;
	}
	
}
