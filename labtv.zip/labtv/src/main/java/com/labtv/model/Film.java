package com.labtv.model;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;

import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="films")
public class Film {
	
	@Id
	private String id;
	
	@OneToMany(
			mappedBy = "films",
			orphanRemoval = true,
			cascade = CascadeType.REFRESH,
			fetch = FetchType.EAGER)
	private List<Trailer> trailers= new ArrayList<Trailer>();
	
	@Column(name="image")
	private String image;
	
	@Column(name="title")
	private String title;
	
	@Column(name="plot")
	private String plot;

	@ManyToOne
	@JoinColumn(name="star",referencedColumnName = "id")
	private Star stars;
	
	@ManyToOne
	@JoinColumn(name="director",referencedColumnName = "id")
	private Director directors;
	
	@ManyToOne
	@JoinColumn(name="genre",referencedColumnName = "id")
	private Genre genres;
	
	@ManyToOne
	@JoinColumn(name="similar",referencedColumnName = "id")
	private Similar similars;
	
	public String getIdFilm() {
		return this.id;
	}
	
	public void setIdFilm(String id_film) {
		this.id=id_film;
	}
	
	public String getImageFilm() {
		return this.image;
	}
	
	public void setImageFilm(String image) {
		this.image=image;
	}
	
	public String getTitleFilm() {
		return this.title;
	}
	
	public void setTitleFilm(String title) {
		this.title=title;
	}
	
	public String getPlotFilm() {
		return this.plot;
	}
	
	public void setPlotFilm(String plot) {
		this.plot=plot;
	}
	
	public Star getStar() {
		return this.stars;
	}
	
	public void setStar(Star star) {
		this.stars=star;
	}
	
	public Director getDirector() {
		return this.directors;
	}
	
	public void setDirector(Director director) {
		this.directors=director;
	}
	
	public Genre getGenre() {
		return this.genres;
	}
	
	public void setGenre(Genre genre) {
		this.genres=genre;
	}
	
	public Similar getSimilar() {
		return this.similars;
	}
	
	public void setSimilar(Similar similar) {
		this.similars=similar;
	}
	
}
