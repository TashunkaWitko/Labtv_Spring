package com.labtv.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.labtv.model.Trailer;

public interface TrailerDao extends CrudRepository<Trailer, Integer>{
	
	@Query(value="SELECT * FROM trailers WHERE id_film= :id",nativeQuery = true)
	List<Trailer> getTrailerByIdFilm(@Param("id") String id);

}
