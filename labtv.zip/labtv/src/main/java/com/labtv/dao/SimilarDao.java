package com.labtv.dao;

import org.springframework.data.repository.CrudRepository;

import com.labtv.model.Similar;

public interface SimilarDao extends CrudRepository<Similar,Integer> {

}
