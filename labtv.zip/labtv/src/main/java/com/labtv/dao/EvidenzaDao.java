package com.labtv.dao;

import org.springframework.data.repository.CrudRepository;

import com.labtv.model.Evidenza;


public interface EvidenzaDao extends CrudRepository<Evidenza, Integer> {

}
