package com.labtv.dao;

import org.springframework.data.repository.CrudRepository;

import com.labtv.model.Star;

public interface StarDao extends CrudRepository<Star, Integer> {

}
