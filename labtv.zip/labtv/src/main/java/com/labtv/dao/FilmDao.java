package com.labtv.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.labtv.model.Film;

public interface FilmDao extends CrudRepository<Film, Integer> {
	
	@Query(value = "SELECT * FROM films WHERE id= :id ", nativeQuery = true)
	List<Film> getFilmByID(@Param("id") String id);
	
	//Chiamata parametrica con id del Film

	@Query(value = "SELECT * FROM films WHERE title LIKE %:title%", nativeQuery = true)
	List<Film> getFilmByTitle(@Param("title") String title);
	
	//Chiamata parametrica per cercare il film tramite il titolo, %:title% non restringono il campo ad una ricerca esatta
}
