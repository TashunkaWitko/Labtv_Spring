package com.labtv.dao;

import org.springframework.data.repository.CrudRepository;

import com.labtv.model.Genre;

public interface GenreDao extends CrudRepository<Genre, Integer> {

}
