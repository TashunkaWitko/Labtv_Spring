package com.labtv.dao;

import org.springframework.data.repository.CrudRepository;

import com.labtv.model.Director;

public interface DirectorDao extends CrudRepository<Director, Integer> {

}
